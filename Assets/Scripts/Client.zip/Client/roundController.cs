using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class roundController : MonoBehaviour
{
    public int angEnd = 225;
    public int angStart = -45;
    int myCardsStart = -500;
    int myCardsWidth = 1000;
    int dist = 500;   //Distance from the centre

    /*
    public int ct;
    int temp_ct;
    public string turn;
    public int dstack;
    public bool sw;
    bool temp_sw;
    public string dirr;
    public float releaseDist;
    public CColor clr;
    public Value val;
    */

    public float detectionDistX;
    public float detectionDistY;
    public GameObject playerPrefab;
    public GameObject cardPrefab;
    public GameObject myCardPrefab;
    public GameObject discard;
    public Transform playerSpawn;
    public Transform myCards;
    public List<GameObject> thisCards = new List<GameObject>();

    public Image innerBase;
    public Image outerBase;
    public Transform directionArrows;
    public Transform turnOfArrow;
    public Transform drawStack;
    public Transform unoController;
    public Transform dosController;
    public Transform winnerController;
    public GameObject colorChooser;
    public GameObject earlyUno;
    public GameObject menu;
    public gameController gc;

    List<Sprite> colorSprites = new List<Sprite>();
    List<Sprite> valueSprites = new List<Sprite>();

    bool choosingColor = false;
    string tempCard;
    GameObject hoveredCard;
    Lobby myGame;
    AudioSource audioSource;

    AudioClip clip_plussed;
    AudioClip clip_uno;
    AudioClip clip_dos;

    Color CGREEN = new Color(0.163f, 0.543f, 0f);
    Color CRED = new Color(0.78f, 0.085f, 0f);
    Color CBLUE = new Color(0f, 0.291f, 0.659f);
    Color CYELLOW = new Color(0.915f, 0.819f, 0f);

    
    void Awake()
    {
        colorSprites.Add(Resources.Load<Sprite>("c_blue"));
        colorSprites.Add(Resources.Load<Sprite>("c_green"));
        colorSprites.Add(Resources.Load<Sprite>("c_red"));
        colorSprites.Add(Resources.Load<Sprite>("c_yellow"));
        colorSprites.Add(Resources.Load<Sprite>("c_k_black"));

        for (int i = 0; i<10; i++) valueSprites.Add(Resources.Load<Sprite>("v_"+i.ToString()));
        valueSprites.Add(Resources.Load<Sprite>("a_reverse"));
        valueSprites.Add(Resources.Load<Sprite>("a_block"));
        valueSprites.Add(Resources.Load<Sprite>("a_t_plus2"));
        valueSprites.Add(Resources.Load<Sprite>("a_f_plus4"));
        valueSprites.Add(Resources.Load<Sprite>("a_color"));

        audioSource = GetComponent<AudioSource>();
        clip_plussed = Resources.Load<AudioClip>("plussed");
        clip_uno= Resources.Load<AudioClip>("uno");
        clip_dos= Resources.Load<AudioClip>("dos");
    }

    private void OnEnable()
    {
        for (int i = 0; i < valueSprites.Count; i++) if (valueSprites[i].name.Contains("a_f_plus")) valueSprites[i] = Resources.Load<Sprite>("a_f_plus" + (gc.myName.ToLower() != "zak" ? "4" : "5"));
    }

    void FixedUpdate()
    {
        //Todo: clear up here and variable declarations
        /*if (temp_ct != ct) {
            List<Card> cds = new List<Card>();
            for (int i = 0; i < ct; i++)
            {
                Card c = new Card();
                c.color = clr;
                c.value = val;
                cds.Add(c);
            }
            showCards(cds);
            temp_ct = ct;

            //////////////////////////
            Lobby l = new Lobby();
            l.last = clr.ToString() + val.ToString();
            l.color = clr.ToString();
            l.direction = dirr;
            l.turnOf = turn;
            l.drawStack = dstack;
            List<Player> pls = new List<Player>();
            for (int i = 0; i < ct; i++)
            {
                Player p = new Player();
                p.name = "Player " + (i + 1);
                p.cardCt = i + 1;
                pls.Add(p);
            }
            l.players = pls;
            onGameUpdate(l);
            //////////////////////////
        }
        /////////////////////////////////////
        if (sw != temp_sw)
        {
            if (sw) onUnoCall(turn);
            else onDosCall(turn);
        }
        temp_sw = sw;
        /////////////////////////////////////
        */

        Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        int n = 0;
        foreach (GameObject card in thisCards)
        {
            card.transform.SetSiblingIndex(n);
            if (inRange(card, mousePos))
            {
                if (hoveredCard != null)
                {
                    if (Mathf.Abs(hoveredCard.transform.position.x - mousePos.x) > Mathf.Abs(card.transform.position.x - mousePos.x)) hoveredCard = card;
                }
                else hoveredCard = card;

            }
            else if (hoveredCard == card) hoveredCard = null;
            n++;
        }
        foreach (GameObject card in thisCards) if (card != hoveredCard && card.transform.localPosition.y > 0) card.transform.Translate(Vector3.down * 0.1f);
        if (hoveredCard)
        {
            if(hoveredCard.transform.localPosition.y < 100)hoveredCard.transform.Translate(Vector3.up * 0.1f);
            hoveredCard.transform.SetAsLastSibling();
        }

        //shrink discard
        if (discard.transform.localScale.x > 1) discard.transform.localScale = Vector2.one * (discard.transform.localScale.x - 0.01f);

        directionArrows.Rotate(Vector3.forward, -0.1f);
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (hoveredCard && !choosingColor)
            {
                tempCard = hoveredCard.transform.Find("color").gameObject.GetComponentInChildren<Image>().sprite.name[2].ToString() + hoveredCard.transform.Find("value").gameObject.GetComponentInChildren<Image>().sprite.name[2].ToString();
                if (tempCard[0] != 'k') reqPlayCard(tempCard);
                else
                {
                    choosingColor = true;
                    colorChooser.SetActive(true);
                }
                return;
            }

            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            if (choosingColor && (Mathf.Pow(mousePos.x, 2) + Mathf.Pow(mousePos.y, 2) <= Mathf.Pow(1.80f, 2))) //color pick
            {
                char color = ' ';
                if (mousePos.x >= 0 && mousePos.y >= 0) color = 'r';
                if (mousePos.x > 0 && mousePos.y < 0) color = 'g';
                if (mousePos.x < 0 && mousePos.y < 0) color = 'y';
                if (mousePos.x < 0 && mousePos.y > 0) color = 'b';

                choosingColor = false;
                colorChooser.SetActive(false);

                reqPlayCard(tempCard + color);
            }
            else //cancel if clicked outside
            {
                choosingColor = false;
                colorChooser.SetActive(false);
            }
        }
    }

    void reqPlayCard(string card)
    {
        gc.reqPlayCard(card);
    }

    bool inRange(GameObject a, Vector2 b) { return (Mathf.Abs(a.transform.position.x - b.x) < detectionDistX) && (Mathf.Abs(a.transform.position.y - b.y) < detectionDistY); }

    public Transform spawnPlayers(List<Player> players, string turnOfName)
    {
        Transform turnOf = null;

        //Clear players
        foreach (Transform child in playerSpawn) Destroy(child.gameObject);

        int ct = players.Count - 1;
        float angBetween = (angEnd - angStart) / (ct + 1f); //calculate angle diff between players by dividing available angle range to number of gaps between players (ct+1)
        int i = 1;
        foreach (Player pl in players)
        {
            if (pl.name == gc.myName) continue;
            GameObject p = Instantiate(playerPrefab, playerSpawn);
            float ang = Mathf.Deg2Rad * (angStart + i * angBetween);
            p.transform.localPosition = new Vector2(Mathf.Cos(ang) * dist * 1.5f, Mathf.Sin(ang)*dist);
            p.GetComponentInChildren<TextMeshProUGUI>().text = pl.name;
            if (pl.name == turnOfName) turnOf = p.transform;

            for (int n = 1; n <= pl.cardCt; n++)
            {
                GameObject c = Instantiate(cardPrefab, p.transform);
                c.transform.Rotate(0, 0, 30 - n*(60/(pl.cardCt+1)));
                c.transform.SetSiblingIndex(n - 1);
            }

            i++;
        }

        return turnOf;
    }

    public void showCards(List<Card> cards)
    {
        foreach (Transform child in myCards) Destroy(child.gameObject);
        thisCards.Clear();

        for (int i = 0; i < cards.Count; i++)
        {
            GameObject c = Instantiate(myCardPrefab, myCards);
            thisCards.Add(c);
            c.transform.Find("color").gameObject.GetComponentInChildren<Image>().sprite = colorSprites[(int)(cards[i].color)];
            c.transform.Find("value").gameObject.GetComponentInChildren<Image>().sprite = valueSprites[(int)(cards[i].value)];
            c.transform.localPosition = new Vector2(myCardsStart + (i+1)*(myCardsWidth/(cards.Count+1)), 0);
        }
    }

    public void onGameUpdate(Lobby game)
    {
        earlyUno.SetActive(false);

        foreach (Player p in game.players)
        {
            if (p.cardCt == 0)
            {
                winnerController.GetComponentInChildren<TextMeshProUGUI>(true).text = p.name;
                winnerController.GetComponent<Animator>().Play("on");
                break;
            }
        }

        if (myGame != null) //if it's not the initialising update
        {
            //TODO: (if going to utilise this area) Don't forget to not to not to consider restarting a game as a game update. Might set myGame to null when game finished.

            //Check here for specific changes to show effects. e.g. direction changed, got plussed, 

            if (game.drawStack != myGame.drawStack && game.drawStack != 0)
            {
                audioSource.clip = clip_plussed;
                audioSource.PlayOneShot(clip_plussed, Mathf.Min(game.drawStack/16f, 1));
            }
        }

        myGame = game;

        discard.transform.Find("color").gameObject.GetComponentInChildren<Image>().sprite = colorSprites[(int)Card.char2color(game.last[0])];
        discard.transform.Find("value").gameObject.GetComponentInChildren<Image>().sprite = valueSprites[(int)Card.char2value(game.last[1])];
        discard.transform.localScale = Vector2.one * 1.2f;

        switch (game.color)
        {
            case "b":
                outerBase.color = CBLUE;
                break;
                
            case "g":
                outerBase.color = CGREEN;
                break;
                
            case "r":
                outerBase.color = CRED;
                break;
                
            case "y":
                outerBase.color = CYELLOW;
                break;
        }

        directionArrows.eulerAngles = new Vector3(directionArrows.eulerAngles.x, game.direction == "clock" ? 180 : 0, directionArrows.eulerAngles.z);   //set direction

        Transform to = spawnPlayers(game.players, game.turnOf);
        turnOfArrow.up = ((to ? to : myCards).position - turnOfArrow.position);
        if (to) to.Find("Panel").GetComponent<Image>().color = Color.green;

        if (game.drawStack > 0)
        {
            drawStack.Find("plus").gameObject.SetActive(true);
            drawStack.GetComponentInChildren<TextMeshProUGUI>().text = "+" + game.drawStack;
        }
        else drawStack.Find("plus").gameObject.SetActive(false);

        showCards(game.myCards);
    }

    public void reqUnoCall() => gc.reqUnoCall();
    public void reqDosCall() => gc.reqDosCall();

    public void onEarlyUnoAccepted()
    {
        earlyUno.SetActive(true);
    }

    public void onUnoCall(string player)
    {
        Debug.Log(player);
        unoController.position = new Vector3(0, -2.5f, 0);
        foreach (Transform child in playerSpawn)
            if (child.gameObject.GetComponentInChildren<TextMeshProUGUI>().text == player) unoController.position = child.transform.position;
        unoController.GetComponent<Animator>().Play("on");
        audioSource.PlayOneShot(clip_uno, 0.4f);
    }

    public void onDosCall(string player)
    {
        Debug.Log(player);
        dosController.position = new Vector3(0, -2.5f, 0);
        foreach (Transform child in playerSpawn)
            if (child.gameObject.GetComponentInChildren<TextMeshProUGUI>().text == player) dosController.position = child.transform.position;
        dosController.GetComponent<Animator>().Play("on");
        audioSource.PlayOneShot(clip_dos, 0.4f);
    }

    public void reqDraw() => gc.reqDraw();

    public void showMenu() => menu.SetActive(true);

    public void leave()
    {
        menu.SetActive(false);
        if (gc.lc.isOwner)
        {
            gc.notifyReturnLobby();
            gc.switchToLobby();
        }
        else
        {
            gc.reqLeaveLobby();
            gc.switchToLobbies();
        }
    }
}
