using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using UnityEngine;

public class clientController : MonoBehaviour
{
    public gameController gc;

    internal bool socketReady = false;
    TcpClient mySocket;
    NetworkStream theStream;
    StreamWriter theWriter;
    StreamReader theReader;
    public string Host = "185.31.40.78";
    public int Port = 8300;
    
    void Update()
    {

        string read;
        while ((read = readSocket()) != "")
            handleServerMsg(read.Substring(0, read.IndexOf('\0')));
    }

    void handleServerMsg(string msg)
    {
        Debug.Log("Received: " + msg);
        switch (msg.Substring(0,4))
        {
            case "LSLB":
                parseLobbyList(msg.Substring(4));
                break;

            case "JOIN":
                parseJoinLobby(msg.Substring(4));
                break;

            case "LBUP":
                parseLobbyUpdate(msg.Substring(4));
                break;

            case "GMUP":
                parseGameUpdate(msg.Substring(4));
                break;

            case "EUNO":
                gc.receiveEarlyUnoAccepted();
                break;

            case "CUNO":
                gc.receiveUnoCall(msg.Substring(4));
                break;

            case "CDOS":
                gc.receiveDosCall(msg.Substring(4));
                break;
        }
    }

    #region SendingRequests

    public void reqListLobbies() => writeSocket("LSLB");
    public void reqJoinLobby(string id, string name) => writeSocket("JNLB"+id+">"+name);
    public void reqCreateLobby(string name) => writeSocket("CRTL"+name);
    public void reqLeaveLobby(string id) => writeSocket("LVLB"+id);
    public void reqSetLobbyName(string id, string name) => writeSocket("SETN"+id+">NM"+name);
    public void reqSetCardsPerP(string id, int n) => writeSocket("SETN"+id+">CP"+n);
    public void reqSetUnoPenalty(string id, int n) => writeSocket("SETN"+id+">UP"+n);
    public void reqStart(string id) => writeSocket("STRT"+id);
    public void reqPlayCard(string id, string card) => writeSocket("PLAY"+id+">"+card);
    public void reqUnoCall(string id) => writeSocket("CUNO"+id);
    public void reqDosCall(string id) => writeSocket("CDOS"+id);
    public void reqDraw(string id) => writeSocket("DRAW"+id);
    public void notifyReturnLobby(string id) => writeSocket("RTLB"+id);

    #endregion

    #region ParsingMessages

    void parseLobbyList(string list)
    {
        string[] lobbies = list.Split("<n>");
        List<Lobby> result = new List<Lobby>();

        foreach (string lobby in lobbies)
        {
            if (lobby == "") break;

            Lobby r = new Lobby();
            r.name =  lobby.Split("|")[0];
            r.id = lobby.Split("|")[1];
            r.gameState = lobby.Split("|")[2]; r.gameState = r.gameState.Substring(0, r.gameState.IndexOf('<'));
            string players = lobby.Split("<PL>")[1];
            foreach (string player in players.Split(","))
            {
                Player p = new Player();
                p.name = player;
                r.players.Add(p);
            }

            result.Add(r);
        }

        gc.receiveLobbyList(result);
    }

    void parseJoinLobby(string lobby)
    {
         if (lobby == "") return;

        Lobby r = new Lobby();
        lobby = lobby.Split("<NM>")[1];
        r.name = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<ST>")[1];
        r.gameState = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<OW>")[1];
        r.owner = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<ID>")[1];
        r.id = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<CP>")[1];
        r.cardsPerP = int.Parse(lobby.Substring(0, lobby.IndexOf('<')));

        lobby = lobby.Split("<UP>")[1];
        r.unoPenalty = int.Parse(lobby.Substring(0, lobby.IndexOf('<')));

        string players = lobby.Split("<PL>")[1];
        foreach (string player in players.Split("|"))
        {
            Player p = new Player();
            p.name = player;
            r.players.Add(p);
        }

        gc.receiveJoinLobby(r);
    }

    void parseLobbyUpdate(string lobby)
    {
        if (lobby == "") return;

        Lobby r = new Lobby();
        lobby = lobby.Split("<NM>")[1];
        r.name = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<ST>")[1];
        r.gameState = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<OW>")[1];
        r.owner = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<ID>")[1];
        r.id = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<CP>")[1];
        r.cardsPerP = int.Parse(lobby.Substring(0, lobby.IndexOf('<')));

        lobby = lobby.Split("<UP>")[1];
        r.unoPenalty = int.Parse(lobby.Substring(0, lobby.IndexOf('<')));

        string players = lobby.Split("<PL>")[1];
        foreach (string player in players.Split("|"))
        {
            Player n = new Player();
            n.name = player;
            r.players.Add(n);
        }

        gc.receiveLobbyUpdate(r);
    }

    void parseGameUpdate(string lobby)
    {
        if (lobby == "") return;

        Lobby r = new Lobby();
        lobby = lobby.Split("<DR>")[1];
        r.direction = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<LS>")[1];
        r.last = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<CL>")[1];
        r.color = lobby.Substring(0, lobby.IndexOf('<'));

        lobby = lobby.Split("<DS>")[1];
        r.drawStack = int.Parse(lobby.Substring(0, lobby.IndexOf('<')));

        lobby = lobby.Split("<TO>")[1];
        r.turnOf = lobby.Substring(0, lobby.IndexOf('<'));

        string players = lobby.Split("<PL>")[1];
        foreach (string player in players.Split("|"))
        {
            Player p = new Player();
            p.name = player.Substring(0, player.IndexOf('['));
            p.cardCt =  int.Parse(player.Substring(player.IndexOf('[')+1, player.IndexOf(']') - (player.IndexOf('[') + 1)));
            r.players.Add(p);
        }
        
        string myCards = lobby.Split("<ME>").Length > 1 ?  lobby.Split("<ME>")[1] : "";
        if (myCards != "")
        {
            foreach (string card in myCards.Split(","))
            {
                Card c = new Card();
                c.color = Card.char2color(card[0]);
                c.value = Card.char2value(card[1]);
                r.myCards.Add(c);
            }
        }

        gc.receiveGameUpdate(r);
    }

    #endregion

    /* Blocking function.
     * If no connection, resets/initiates a connection.
     * If connection, tries sending a test package and listens for 1 second (BLOCKING) for a positive response.
     * If testing fails, connection is set to no connection.
     * If no connection in the end, game controller is alerted.
     */
    public void checkConnection()
    {
        if (socketReady)
        {
            try
            {
                writeSocket("TEST");
                string read;
                int tries = 0;
                while (!(read = readSocket()).Contains("CONN_OK"))
                {
                    wait(0.2f);
                    if (tries++ > 10) break;
                }
                socketReady = (read.Contains("CONN_OK"));

            }
            catch (Exception)
            {
                socketReady = false;
            }
        }
        else resetSocket();

        if (!socketReady) gc.lostConnection();
        else gc.isConnected();
    }

    public void wait(float d)
    {
        long st = DateTimeOffset.Now.ToUnixTimeMilliseconds();
        while (DateTimeOffset.Now.ToUnixTimeMilliseconds() - st < d*1000) continue;
    }

    #region SocketFunctions
    void resetSocket()
    {
        closeSocket();
        setupSocket();
    }

    public void setupSocket()
    {
        try
        {
            mySocket = new TcpClient(Host, Port);
            theStream = mySocket.GetStream();
            theWriter = new StreamWriter(theStream);
            theReader = new StreamReader(theStream);
            socketReady = true;
        }
        catch (Exception e)
        {
            Debug.Log("Socket error: " + e);
        }
    }
    public void writeSocket(string theLine)
    {
        if (!socketReady)
            return;
        String foo = theLine + "\r\n";
        theWriter.Write(foo);
        theWriter.Flush();
    }
    public String readSocket()
    {
        if (!socketReady)
            return "";
        string read = "";

        if (theStream.DataAvailable)
        {
            //read = theReader.ReadLine();
            char[] r = new char[2048];
            theReader.Read(r, 0, 2048);
            read = new string(r);
        }
        return read;
    }
    public void closeSocket()
    {
        if (!socketReady)
            return;
        writeSocket("CLOS");
        theWriter.Close();
        theReader.Close();
        mySocket.Close();
        socketReady = false;
    }
    #endregion
}
