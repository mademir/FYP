using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class lobbyController : MonoBehaviour
{
    public TMP_InputField Name;
    public TMP_InputField CPP;
    public TMP_InputField UP;
    public gameController gc;
    public TMP_InputField CPPField;
    public Transform playerListGO;
    public GameObject playerEntry;
    public GameObject startBtn;
    private bool _isOwner;
    int playerCt = 0;
    public bool isOwner { get { return _isOwner; } set { switchOwner(value); } }

    public void setName(string n) => Name.text = n;
    public void setCardsPerP(int n) => CPP.text = n.ToString();
    public void setUnoPenalty(int n) => UP.text = n.ToString();

    public void addPlayer(string name, bool owner)
    {
        playerCt++;
        GameObject p = Instantiate(playerEntry, playerListGO);
        p.transform.Find("name").GetComponent<TextMeshProUGUI>().text = name;
        if (owner) p.transform.Find("owner").gameObject.SetActive(true);
    }

    public void clearAllPlayers()
    {
        //Clear players
        foreach (Transform child in playerListGO)
        {
            Destroy(child.gameObject);
        }
        playerCt = 0;
    }

    void switchOwner(bool owner)
    {
        _isOwner = owner;
        //enable start button, enable lobby name and settings editing
        Name.readOnly = !owner;
        CPP.readOnly = !owner;
        UP.readOnly = !owner;
        startBtn.SetActive(owner);
    }

    public void onLobbyNameChange()
    {
        if (isOwner) gc.reqSetLobbyName(Name.text);
    }

    public void checkCardsPerP(int num)
    {
        if (num < 2) gc.reqSetCardsPerP(2);
        else if (num * playerCt > 90) gc.reqSetCardsPerP(90 / playerCt);

    }
    public void onCardsPerPChange(TMP_InputField f)
    {
        if (f.text == "") return;
        int num = int.Parse(f.text);
        if (num < 2) gc.reqSetCardsPerP(2);
        else if (num * playerCt > 90) gc.reqSetCardsPerP(90 / playerCt);
        else gc.reqSetCardsPerP(num);
    }

    public void onUnoPenalty(TMP_InputField f)
    {
        if (f.text == "") return;
        int num = int.Parse(f.text);
        if (num < 0) f.text = "0";
        else if (num > 10) f.text = "10";

        num = int.Parse(f.text);

        gc.reqSetUnoPenalty(num);
    }

    public void reqStart() => gc.reqStart();

}
