public class Player { 
    public string name;
    public int cardCt;
}
