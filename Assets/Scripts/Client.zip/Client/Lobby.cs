using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lobby
{
    public string name;
    public string gameState;
    public string owner;
    public string id;
    public int cardsPerP;
    public int unoPenalty;

    public string direction;
    public string last;
    public string color;
    public int drawStack;
    public string turnOf;

    public List<Player> players = new List<Player>();
    public List<Card> myCards = new List<Card>();
}
