using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class gameController : MonoBehaviour
{
    public GameObject MainMenu;
    public GameObject LobbiesView;
    public GameObject LobbyView;
    public GameObject RoundView;
    public clientController cc;
    public lobbyController lc;
    public roundController rc;
    public Transform LobbyListGO;
    public GameObject connectionLostMsg;
    public GameObject lobbyEntry;
    public GameObject nameField;
    public GameObject muteToggle;

    private static readonly int VERSION = 908453;

    public string myName { get { return nameField.GetComponentInChildren<TMP_InputField>().text; } }
    Lobby myLobby;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSplashScreen)] 
    static void atBegin()
    {
        string[] args = System.Environment.GetCommandLineArgs();

        if (args.Length == 3)
        {
            if (System.Environment.GetCommandLineArgs()[1] == "check")
                Application.Quit(System.Environment.GetCommandLineArgs()[2] == VERSION.ToString() ? 500 : -1);

            else if (System.Environment.GetCommandLineArgs()[1] == "run") {if (System.Environment.GetCommandLineArgs()[2] != VERSION.ToString()) Application.Quit();}
                
            else Application.Quit();
        }else Application.Quit();
    }

    private void Awake()
    {
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = 30;
    }

    // Start is called before the first frame update
    void Start()
    {
        switchToMainMenu();
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnApplicationQuit()
    {
        CloseGame();
    }

    public void CloseGame()
    {
        cc.closeSocket();
        Application.Quit();
    }

    public void isConnected()
    {
        connectionLostMsg.SetActive(false);
    }

    public void lostConnection()    //Idea: add stuff to handle connection lost during game
    {
        if (LobbiesView.activeSelf) //if in lobbies view
        {
            connectionLostMsg.SetActive(true);
        }
    }

    public void onMuteToggle()
    {
        bool muteState = muteToggle.activeSelf;
        muteToggle.SetActive(!muteState);
        if (muteState) GetComponent<AudioSource>().UnPause();
        else GetComponent<AudioSource>().Pause();
    }

    public void switchToLobbies()
    {
        if (LobbyView.activeSelf) reqLeaveLobby(); //if exiting lobby, tell cc to call leave lobby
        if (myName == "") return;
        nameField.SetActive(false);
        MainMenu.SetActive(false);
        LobbyView.SetActive(false);
        RoundView.SetActive(false);
        LobbiesView.SetActive(true);
        cc.checkConnection();
        reqListLobbies();
    }

    public void switchToMainMenu()
    {
        LobbyView.SetActive(false);
        LobbiesView.SetActive(false);
        MainMenu.SetActive(true);
        nameField.SetActive(true);
        connectionLostMsg.SetActive(false);
        RoundView.SetActive(false);
    }

    public void switchToLobby()
    {
        LobbiesView.SetActive(false);
        MainMenu.SetActive(false);
        nameField.SetActive(false);
        connectionLostMsg.SetActive(false);
        RoundView.SetActive(false);
        LobbyView.SetActive(true);
        updateLobby();
    }

    public void switchToRound()
    {
        LobbiesView.SetActive(false);
        MainMenu.SetActive(false);
        nameField.SetActive(false);
        connectionLostMsg.SetActive(false);
        LobbyView.SetActive(false);
        RoundView.SetActive(true);
    }



    #region LSLB
    public void reqListLobbies() => cc.reqListLobbies();

    public void receiveLobbyList(List<Lobby> lobbies)   //should be called from client controller
    {
        //Clear lobbies
        foreach (Transform child in LobbyListGO)
        {
            Destroy(child.gameObject);
        }

        if (LobbiesView.activeSelf) //if in lobbies view
        {
            foreach (Lobby l in lobbies)
            {
                GameObject entry = Instantiate(lobbyEntry, LobbyListGO);
                entry.transform.Find("name").GetComponent<TextMeshProUGUI>().text = l.name;
                entry.transform.Find("count").GetComponent<TextMeshProUGUI>().text = l.players.Count + " players";
                entry.transform.Find("state").GetComponent<TextMeshProUGUI>().text = l.gameState.Substring(0, 2) + " " + l.gameState.Substring(2);
                entry.transform.Find("state").GetComponent<TextMeshProUGUI>().color = l.gameState == "inLobby" ? Color.green : Color.red;
                entry.GetComponentInChildren<Button>().onClick.AddListener(() => reqJoinLobby(l.id));
            }
        }
    }
    #endregion

    void reqJoinLobby(string id) => cc.reqJoinLobby(id, myName);
    public void reqLeaveLobby() => cc.reqLeaveLobby(myLobby.id);

    public void receiveJoinLobby(Lobby lobby)
    {
        myLobby = lobby;
        switchToLobby();
    }

    public void reqCreateLobby() => cc.reqCreateLobby(myName);
    public void reqSetLobbyName(string name) => cc.reqSetLobbyName(myLobby.id, name);
    public void reqSetCardsPerP(int n) => cc.reqSetCardsPerP(myLobby.id, n);
    public void reqSetUnoPenalty(int n) => cc.reqSetUnoPenalty(myLobby.id, n);
    public void reqStart() => cc.reqStart(myLobby.id);
    public void reqPlayCard(string card) => cc.reqPlayCard(myLobby.id, card);
    public void reqUnoCall() => cc.reqUnoCall(myLobby.id);
    public void reqDosCall() => cc.reqDosCall(myLobby.id);
    public void reqDraw() => cc.reqDraw(myLobby.id);
    public void notifyReturnLobby() => cc.notifyReturnLobby(myLobby.id);

    public void receiveLobbyUpdate(Lobby lobby)
    {
        if (myLobby.gameState == "inGame" && lobby.gameState == "inLobby") switchToLobby();
        if (!LobbyView.activeSelf) return;
        myLobby = lobby;
        updateLobby();
    }

    void updateLobby()  //receiveLobbyUpdate should also call this after setting myLobby
    {
        lc.setName(myLobby.name);
        lc.isOwner = myName == myLobby.owner;
        lc.setCardsPerP(myLobby.cardsPerP);
        lc.setUnoPenalty(myLobby.unoPenalty);
        lc.clearAllPlayers();
        foreach (Player player in myLobby.players) lc.addPlayer(player.name, myLobby.owner == player.name);
        lc.checkCardsPerP(myLobby.cardsPerP);
    }

    public void receiveGameUpdate(Lobby lobby)
    {
        if (LobbyView.activeSelf) switchToRound();
        rc.onGameUpdate(lobby);
    }

    public void receiveEarlyUnoAccepted() => rc.onEarlyUnoAccepted();
    public void receiveUnoCall(string player) => rc.onUnoCall(player);
    public void receiveDosCall(string player) => rc.onDosCall(player);

}
