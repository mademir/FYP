﻿namespace Networking
{
    public class Client
    {
    }
}