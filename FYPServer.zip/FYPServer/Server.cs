using System.Net;
using System.Net.Sockets;

namespace Networking {
    class Server
    {
        /*public static int MaxClients { get; private set; }
        public static int Port { get; private set; }
        public static Dictionary<int, Client> clients = new Dictionary<int, Client>();

        private static TcpListener tcpListener;
        private static UdpClient udpListener;

        public static void Start(int maxClients, int port)
        {
            MaxClients = maxClients;
            Port = port;

            Console.WriteLine("Starting the server.");

            for (int i = 1; i <= MaxClients; i++)
            {
                clients.Add(i, new Client(i));
            }

            tcpListener = new TcpListener(IPAddress.Any, Port);
            tcpListener.Start();
            tcpListener.BeginAcceptTcpClient(TCPConnectCallback, null);

            udpListener = new UdpClient(Port);
            udpListener.BeginReceive(UDPReceiveCallback, null);

            Console.WriteLine($"Server started on port {Port}.");
        }*/


    }
}